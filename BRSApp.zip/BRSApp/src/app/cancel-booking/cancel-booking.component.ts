import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { BusService } from '../app.busservice';

@Component({
  selector: 'app-cancel-booking',
  templateUrl: './cancel-booking.component.html',
  styleUrls: ['./cancel-booking.component.css'],
  providers: [BusService]
})
export class CancelBookingComponent implements OnInit {

  showMsg :boolean;
   bookId:number
  constructor(private busService:BusService) { }

  ngOnInit() {
    // this.cancelTicketsForm = this.formBuilder.group({
    //   bookingId: ['', Validators.required]
    // });
  }
  // onSubmit(){
  //   console.log(this.cancelTicketsForm)
  //   if (this.cancelTicketsForm.invalid == true) {
  //     console.log("invalid")
  //     return;
  //   }else{
  //     console.log("valid")
  //     this.showMsg = true;
  //     return;
  //   }
  //}

  cancelTicketsForm =new FormGroup(
    {
      bookingId:new FormControl(null,[Validators.required,Validators.pattern('[0-9]+')])
    }
  ); 

  cancelBooking(){
    this.bookId=this.cancelTicketsForm.value['bookingId'];
    this.busService.cancelBooking(this.bookId).subscribe(
      data=>{
        console.log(data)
        if(data==null){
          this.showMsg=false
          //alert("Booking id is wrong")
        }
        else{
          this.showMsg=true
          this.cancelTicketsForm.reset();
        }
        
      }
    )
  }

}
