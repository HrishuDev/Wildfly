import { Component, OnInit } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { BusService } from '../app.busservice';

@Component({
  selector: 'app-addbus',
  templateUrl: './addbus.component.html',
  styleUrls: ['./addbus.component.css']
})
export class AddbusComponent implements OnInit {

  constructor(private service: BusService, private http: HttpClient, private router: Router) {

  }

  bus: any = {};

  ngOnInit() {
  }

  addBus() {
    debugger
    console.log(this.bus);
    this.service.addBus(this.bus).subscribe(
      data => {
        alert("Bus Added Successfully");
        this.router.navigate(['/body']);

      },
      error => {
        alert(error.error);
      })



  }

}
