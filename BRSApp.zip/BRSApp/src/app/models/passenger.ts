export class Passenger{
    passengerId:number;
    userId:number;
    name:string;
    gender:string;
    age:number;
}