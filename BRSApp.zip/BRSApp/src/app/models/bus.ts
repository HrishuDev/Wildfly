import { Time } from '@angular/common';



export class Bus{
    busId:number;
    busName:string;
    busType:string;
    busClass:string;
    noOfSeats:number;
    source:string;
    destination:string;
    startTime:Time;
    costperSeat:number;
}