import { Booking } from './booking';
import { Bus } from './bus';
import { User } from './user';

export class Transaction{
    transactionId:number;
    dot:Date;
    totalAmount:number;
    booking:Booking;
    bus:Bus;
    user:User;
}