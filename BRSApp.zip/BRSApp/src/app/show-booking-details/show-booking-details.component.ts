import { Component, OnInit, Input } from '@angular/core';
import { User } from '../models/user';
import { Booking } from '../models/booking';
import { BusService } from '../app.busservice';
import { Bus } from '../models/bus';
import { Passenger } from '../models/passenger';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-show-booking-details',
  templateUrl: './show-booking-details.component.html',
  styleUrls: ['./show-booking-details.component.css'],
  providers: [BusService]
})
export class ShowBookingDetailsComponent implements OnInit {

  //@Input() Customer: Customer;
  bus:Bus={busId:null,busName:null,busType:null,busClass:null,noOfSeats:null,source:null,destination:null,
    startTime:null,costperSeat:null}
    
  // booking:Booking={bookingId:null,userId:null,busId:null,date:null,noofpassengers:null,modeofpay:null,
  //                   totalcost:null,bookingStatus:null}

  booking:Booking[]=[];

  passenger:Passenger={passengerId:null,userId:null,name:null,gender:null,age:null}


  uId:number

  constructor(private busService:BusService,private route:ActivatedRoute,private router:Router) { }

  ngOnInit() {

// this.getBookings(34);
    
//   }

//   getBookings(bookingId:number){
//     this.busService.getBookings(bookingId).subscribe(
//       data=>{
//         console.log(data)
//         this.booking=data
//         this.getBus();
//       }
//     )
//   }

//   getBus(){
//     this.busService.getSingleBus(this.booking.busId).subscribe(
//       data=>{
//             this.bus=data
//       }
//     )



        this.uId=this.route.snapshot.params['userId'];
        console.log("In show "+this.uId);

        this.busService.getBookingByUserId(this.uId).subscribe(
          data=>{
            console.log(this.booking=data)
          }
        )
        
   }
}
