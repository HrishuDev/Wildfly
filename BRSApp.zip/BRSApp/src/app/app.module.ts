import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { CancelBookingComponent } from './cancel-booking/cancel-booking.component';
import { AppRoutingModule } from './app-routing.module';
import { HomeComponent } from './home/home.component';
import { ShowTicketsLeftComponent } from './show-tickets-left/show-tickets-left.component';
import { CreateBookingComponent } from './create-booking/create-booking.component';
import { AddPassengerDetailsComponent } from './add-passenger-details/add-passenger-details.component';
import { ShowBookingDetailsComponent } from './show-booking-details/show-booking-details.component';
import { LoginComponent } from './login/login.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { UserPageComponent } from './userpage/app.userpage';
import { HttpClientModule } from '@angular/common/http';
import { RegisterPageComponent } from './signup/register-page.component';
import { SearchPipe1,SearchPipe2 } from './app.searchpipe';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { AddbusComponent } from './addbus/addbus.component';
import { ShowbusesComponent } from './showbuses/showbuses.component';
import { ShowusersComponent } from './showusers/showusers.component';
import { TransactionsComponent } from './transactions/transactions.component';



@NgModule({
  declarations: [
    AppComponent,
    CancelBookingComponent,
    HomeComponent,
    ShowTicketsLeftComponent,
    CreateBookingComponent,
    AddPassengerDetailsComponent,
    ShowBookingDetailsComponent,
    LoginComponent,
    ForgotPasswordComponent,
    HeaderComponent,
    FooterComponent,
    UserPageComponent,
    RegisterPageComponent,
    SearchPipe1,SearchPipe2,
    AdminhomeComponent,
    AddbusComponent,
    ShowbusesComponent,
    ShowusersComponent,
    TransactionsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
