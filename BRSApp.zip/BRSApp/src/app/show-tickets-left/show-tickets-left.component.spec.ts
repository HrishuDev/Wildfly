import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowTicketsLeftComponent } from './show-tickets-left.component';

describe('ShowTicketsLeftComponent', () => {
  let component: ShowTicketsLeftComponent;
  let fixture: ComponentFixture<ShowTicketsLeftComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowTicketsLeftComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowTicketsLeftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
