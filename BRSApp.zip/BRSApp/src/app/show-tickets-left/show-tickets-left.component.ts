import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { BusService } from '../app.busservice';
import { Bus } from '../models/bus';
import { Booking } from '../models/booking';

@Component({
  selector: 'app-show-tickets-left',
  templateUrl: './show-tickets-left.component.html',
  styleUrls: ['./show-tickets-left.component.css'],
  providers: [BusService]
})
export class ShowTicketsLeftComponent implements OnInit {

  bus:Bus={busId:null,busName:null,busType:null,busClass:null,noOfSeats:null,source:null,destination:null,
            startTime:null,costperSeat:null};

  //booking=new Booking();
  //booking:Booking[];

  showMsg :boolean;
  busNo:number;

  noOfSeat:any;
  
  
  constructor(private busService:BusService) { }

  ngOnInit() {
    
  }

  showSeatsLeftForm=new FormGroup(
    {
      busNum:new FormControl(null,[Validators.required,Validators.pattern('[0-9]+')])
    }
  );

  showSeatsLeft(){
    this.busNo=this.showSeatsLeftForm.value['busNum'];
    console.log(this.busNo);
    this.busService.getSingleBus(this.busNo).subscribe(
      data=>{
        if(data==null){
          this.showMsg=false;
        }
        else{
            this.bus=data
            this.showMsg=true
            this.showSeatsLeftForm.reset();
        }

        this.busService.getseatLeftByBusId(this.busNo).subscribe(
          data=>{
            console.log(data)
            this.noOfSeat=data;
          }
        )
      }
    )
  }





  

}
