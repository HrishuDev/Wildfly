import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { User } from '../models/user';
import { BusService } from '../app.busservice';
import { Bus } from '../models/bus';
import { ActivatedRoute } from '@angular/router';
import { Booking } from '../models/booking';
import { Passenger } from '../models/passenger';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';



@Component({
  selector: 'app-create-booking',
  templateUrl: './create-booking.component.html',
  styleUrls: ['./create-booking.component.css'],
  providers: [BusService]
})
export class CreateBookingComponent implements OnInit {

  bus:Bus={busId:null,busName:null,busType:null,busClass:null,noOfSeats:null,source:null,
    destination:null,startTime:null,costperSeat:null};
  booking=new Booking();
  passenger=new Passenger();
    
  buses:Bus[]=[];
  uId:number;

  noOfpass:number;
  cost:number;
  
  openform:boolean=false;


  bId:number;
  bName:string;
  bType:string;
  bClass:string;
  bSource:string;
  bDes:string;
  tcost:number;


  

  adminSubmitted: boolean = false;
  // datePickerConfig:Partial<BsDatepickerConfig>;
  

  constructor(private busService:BusService,private route:ActivatedRoute) {
  }

  ngOnInit() {

    
    this.uId=this.route.snapshot.params['userId'];
    console.log("In create booking "+this.uId);
    this.getAllBuses();
    
  }

  getAllBuses(){
    this.busService.getAllBuses().subscribe(
      data=>{
        this.buses=data
        console.log(data)
      }
    )
  }

  


  createBookingForm=new FormGroup(
    {
      passenger:new FormControl(null,[Validators.required]),
      age:new FormControl(null,[Validators.required,Validators.pattern('[0-9]+')]),
      gender:new FormControl(null,[Validators.required]),
      busnum:new FormControl(null,[Validators.required]),
      bustype:new FormControl(),
      busname:new FormControl(),
      busclass:new FormControl(),
      dot:new FormControl(null,[Validators.required]),
      passengers:new FormControl(null,[Validators.required,Validators.pattern('[0-9]+')]),
      source:new FormControl(),
      destination:new FormControl(),
      pay:new FormControl(null,[Validators.required]),
      cost:new FormControl(),
      
    }
  );

  addPassengerForm=new FormGroup(
    {
      pname:new FormControl(),
      page:new FormControl(),
      pgender:new FormControl()
    }
  );

   createBooking(createBookingForm:FormGroup):void {
  
    console.log(this.createBookingForm.value);

    this.passenger.name=this.createBookingForm.controls['passenger'].value;
    this.passenger.gender=this.createBookingForm.controls['gender'].value;
    this.passenger.age=this.createBookingForm.controls['age'].value;
    this.passenger.userId=this.uId;

    this.booking.userId=this.uId;
    this.booking.date=this.createBookingForm.controls['dot'].value;
    this.booking.noofpassengers=this.createBookingForm.controls['passengers'].value;
    this.booking.modeofpay=this.createBookingForm.controls['pay'].value;
    this.booking.bookingstatus="Completed";
    
    
    this.booking.busId=this.createBookingForm.controls['busnum'].value;

    this.busService.addBooking(this.booking).subscribe(
      data=>{
        console.log(data);
        alert("Booking successful");
      }
    )
    this.busService.addPassenger(this.passenger).subscribe(
      data=>{
        console.log(data);
      }
    )
    alert("Fill add passenger form "+(this.noOfpass-1)+" times");
  this.createBookingForm.reset();
   }


   onChange(event:any){
    this.bId=event.target.value;
    console.log(event.target.value);
    this.busService.getSingleBus(this.bId).subscribe(
      data=>{
        console.log(this.bus=data)

    
          this.bName=this.bus.busName;
          this.bClass=this.bus.busClass;
          this.bType=this.bus.busType;
          this.bSource=this.bus.source;
          this.bDes=this.bus.destination;
          this.cost=this.bus.costperSeat;
          console.log(this.bus.costperSeat);

      }
    )
   
  }
  
  onChange2(event:any){
    this.noOfpass=event.target.value;
   
    console.log("Passengers"+this.noOfpass);

    this.booking.totalcost=this.cost*this.noOfpass;
    console.log(this.booking.totalcost);
    
      this.tcost=this.booking.totalcost;

       
      
    console.log(this.bName+" "+this.bClass+" "+this.bType+" "+this.bSource+" "+this.bDes+" "+this.tcost)
    
  }


  onClickOpenForm(event:any){
    this.openform=true;
   
    return this.openform;
  
    }


    addPassenger(addPassengerForm:FormGroup){
      this.passenger.userId=this.uId;
      this.passenger.name=this.addPassengerForm.controls['pname'].value;
      this.passenger.age=this.addPassengerForm.controls['page'].value;
      this.passenger.gender=this.addPassengerForm.controls['pgender'].value;

      this.busService.addPassenger(this.passenger).subscribe(
        data=>{
          //console.log(data);
          alert("Passenger added successfully");
          
        }
      )
      addPassengerForm.reset();
    }
  


 
}
