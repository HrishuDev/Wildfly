import { Component, OnInit } from '@angular/core';
import { BusService } from '../app.busservice';
import { Router } from '@angular/router';
import { Bus } from '../models/bus';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [BusService]
})
export class HomeComponent implements OnInit {
   bus:Bus[]=[{busId:null,busName:null,busType:null,busClass:null,noOfSeats:null,source:null,
               destination:null,startTime:null,costperSeat:null}];
  
  //bus:any;
  

  constructor(private busService:BusService,private router:Router) { }

  ngOnInit() {
    this.busService.getAllBuses().subscribe(
      data=>{
        this.bus=data
        console.log(data)
      }
    )
  }

  

}
