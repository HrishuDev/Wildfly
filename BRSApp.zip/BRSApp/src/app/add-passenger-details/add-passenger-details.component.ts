import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { User } from '../models/user';


@Component({
  selector: 'app-add-passenger-details',
  templateUrl: './add-passenger-details.component.html',
  styleUrls: ['./add-passenger-details.component.css']
})
export class AddPassengerDetailsComponent implements OnInit {
  addPassengerDetailsForm: FormGroup;
  user: User = new User();
  adminSubmitted: boolean = false;
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.addPassengerDetailsForm = this.formBuilder.group({
      name: ['', Validators.required],
      age: ['', Validators.required],
      gender: ['', Validators.required],
    });
  }
  onSubmit() {
    console.log(this.addPassengerDetailsForm);
    debugger
    if (this.addPassengerDetailsForm.invalid == true) {
      console.log("Invalid");
      return;
    }
    else
      if (this.addPassengerDetailsForm.controls) {
        var form = this.addPassengerDetailsForm.controls;
        // this.Customer.name = form.name.value;
       
        // this.Customer.age = form.age.value;
        // this.Customer.email = form.email.value;
        // this.Customer.mobile = form.mobile.value;
        // this.Customer.gender = form.gender.value;
        // this.Customer.source = form.source.value;
        // this.Customer.destination = form.destination.value;

        if (this.user) {
          this.adminSubmitted = true;
          alert('Admin Added Successfully...!');
          this.addPassengerDetailsForm.reset();
        }
      }
  }

}
