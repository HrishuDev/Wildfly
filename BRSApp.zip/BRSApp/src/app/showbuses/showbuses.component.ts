import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Bus } from '../models/bus';
import { BusService } from '../app.busservice';



@Component({
  selector: 'app-showbuses',
  templateUrl: './showbuses.component.html',
  styleUrls: ['./showbuses.component.css']
})

export class ShowbusesComponent implements OnInit {
  // ngOnInit(): void {
  //   throw new Error("Method not implemented.");
  // }

  flag: boolean = true;

  busList: Bus[] = [];
  busListCopy: Bus[] = []

  constructor(private service: BusService) {

  }

  ngOnInit() {
    this.service.getAllBuses().subscribe(res => {
      this.busList = res.slice()
      this.busListCopy = res.slice()
    })
  }

  deleteBus(id: any): any {
    this.service.deleteBus(id).subscribe();
    alert("Bus deleted successfully")
    location.reload();
  }


  search(id) {
    this.busList = this.busListCopy
    this.busList = this.busList.filter(x => x.busId == id)
    if (this.busList.length == 0) {
      alert("No Data Found for Id : " + id)
      this.busList = this.busListCopy
    }
  }

  clear() {
    this.busList = this.busListCopy
  }
}
