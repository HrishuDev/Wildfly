import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from "@angular/router";
import { User } from '../models/user';
import { BusService } from '../app.busservice';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [BusService]
})
export class LoginComponent implements OnInit {

  invalidLogin: boolean = false;
  username:string;
  password:string;

  //user: User = new User();

  constructor( private router: Router,private busService:BusService,private route:ActivatedRoute) { }

  ngOnInit() {
      
  }


  loginForm=new FormGroup(
    {
      username:new FormControl(),
      password:new FormControl()
    }
  );
 
loginUser(loginForm:FormGroup){
  this.username=this.loginForm.controls['username'].value;
  this.password=this.loginForm.controls['password'].value;
  
  //console.log(this.userName,this.password)
            if(this.username=='admin' && this.password=='admin'){
                this.router.navigate(['/body']);
            }
            else if(this.username==null)
            {
                alert("Username is Reqired");
            }
            else if(this.password=null)
            {
                alert("Password is Reqired");
            }
            else{       
              
                this.busService.loginUser(this.loginForm.controls['username'].value,this.loginForm.controls['password'].value).subscribe(
                  userId=>{
                    console.log("User id "+userId)
                      this.router.navigate(['/userpage',userId]);
                    
                  },
                
                  error=>{
                    alert("Invalid username or password")
                    this.router.navigate(['/Login'])
                    this.loginForm.reset();
                  }
                )


                // this.router.navigate(['/userpage']);
            }
}  




}