import { Component, OnInit } from '@angular/core';
import { BusService } from '../app.busservice';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { User } from '../models/user';


@Component({
  selector: 'app-register-page',
  templateUrl: './register-page.component.html',
  styleUrls: ['./register-page.component.css'],
  providers: [BusService]
})
export class RegisterPageComponent implements OnInit {

   user:User={userId:null,fname:null,lname:null,username:null,password:null,email:null,
             phoneno:null,dob:null,adharcardno:null}
  //user = new User();

  constructor(private busService:BusService) { }

  ngOnInit() {
  }

  registerForm=new FormGroup(
    {
      fname:new FormControl("",[Validators.required]),
      lname:new FormControl("",[Validators.required]),
      username:new FormControl("",[Validators.required]),
      password:new FormControl("",[Validators.required]),
      cpassword:new FormControl("",[Validators.required]),
      email:new FormControl("",[Validators.required,Validators.email]),
      contact:new FormControl("",[Validators.required,Validators.pattern('[6-9][0-9]{9}')]),
      // usertype:new FormControl(null,[Validators.required]),
      dob:new FormControl("",[Validators.required]),
      adhar:new FormControl("",[Validators.required,Validators.pattern('[0-9]{12}')])
    }
  );

  
  registerUser(registerForm:FormGroup):void{
    //debugger

    var form = this.registerForm.controls;
    this.user.fname=form.fname.value;
    this.user.lname=form.lname.value;
    this.user.username=form.username.value;
    this.user.password=form.password.value;
    this.user.email=form.email.value;
    this.user.phoneno=form.contact.value;
    this.user.adharcardno=form.adhar.value;
    this.user.dob=form.dob.value;

    console.log(this.user);

    if(this.user.password!=this.registerForm.controls['cpassword'].value){
      alert("Password not matching")
    }
  else{
    this.busService.addUser(this.user).subscribe(
      Response=>{
        console.log(Response);
        alert("Registered successfully.");
      }
        
      
    )
   // console.log(this.registerForm.value);
    this.registerForm.reset();
  }
    
  }

}
