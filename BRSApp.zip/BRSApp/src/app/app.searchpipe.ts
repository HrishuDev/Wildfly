import { Pipe, PipeTransform } from '@angular/core';
import { Bus } from './models/bus';

@Pipe(
    {name:"searchPipe1"}
)
export class SearchPipe1 implements PipeTransform
{
    transform(bus:Bus[],search1:any)
    {
        if(search1==undefined)
            return bus;

        return bus.filter(function(bus:Bus)
        {
            console.log("........"+bus);
            return bus.busId.toLocaleString().includes(search1.toLocaleString());
        })
    }
}



@Pipe(
    {name:"searchPipe2"}
)
export class SearchPipe2 implements PipeTransform
{
    transform(bus:Bus[],search2:any)
    {
        if(search2==undefined)
            return bus;

        return bus.filter(function(bus:Bus)
        {
            console.log("........"+bus);
            return bus.busName.toLocaleLowerCase().includes(search2.toLocaleLowerCase());
        })
    }
}