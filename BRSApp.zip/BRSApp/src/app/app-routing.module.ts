import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { CancelBookingComponent } from './cancel-booking/cancel-booking.component';
import { HomeComponent } from './home/home.component';
import { ShowTicketsLeftComponent } from './show-tickets-left/show-tickets-left.component';
import { CreateBookingComponent } from './create-booking/create-booking.component';
import { AddPassengerDetailsComponent } from './add-passenger-details/add-passenger-details.component';
import { ShowBookingDetailsComponent } from './show-booking-details/show-booking-details.component';
import { LoginComponent } from './login/login.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { AppComponent } from './app.component';
import { UserPageComponent } from './userpage/app.userpage';
import { RegisterPageComponent } from './signup/register-page.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { AddbusComponent } from './addbus/addbus.component';
import { ShowbusesComponent } from './showbuses/showbuses.component';
import { ShowusersComponent } from './showusers/showusers.component';
import { TransactionsComponent } from './transactions/transactions.component';



const routes: Routes = [
  {path:"",redirectTo:"home",pathMatch:'full'},
  { path: 'home', component: HomeComponent },
  { path: 'Login', component: LoginComponent },
  {path: 'signup', component: RegisterPageComponent},
  { path: 'Login/forgotPassword', component: ForgotPasswordComponent },
  { path: 'createBookings/:userId', component: CreateBookingComponent },
  { path: 'addPassengerDetails', component: AddPassengerDetailsComponent },
  { path: 'showBookingDetails/:userId', component: ShowBookingDetailsComponent },
  { path: 'cancelBooking/:userId', component: CancelBookingComponent },
  { path: 'showSeatsLeft/:userId', component: ShowTicketsLeftComponent },
  { path: 'userpage/:userId', component: UserPageComponent},
  { path: 'transactions/:bookingId', component: TransactionsComponent},


  {path:'body',component:AdminhomeComponent}, 
  {path:'AddBus',component:AddbusComponent}, 
  {path:'ShowBus',component:ShowbusesComponent},
  {path:'ShowUser',component:ShowusersComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
