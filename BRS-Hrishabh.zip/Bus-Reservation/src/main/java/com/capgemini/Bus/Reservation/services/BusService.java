package com.capgemini.Bus.Reservation.services;

import java.util.List;

import com.capgemini.Bus.Reservation.dao.BusOperationsDao;
import com.capgemini.Bus.Reservation.entity.Bus;
import com.capgemini.Bus.Reservation.entity.User;

public interface BusService extends BusOperationsDao{

	public List<User> showallUsers();
	public void save(User theUser);
	public void deletebus(int busid);
	public Bus findById(int theId);
}
