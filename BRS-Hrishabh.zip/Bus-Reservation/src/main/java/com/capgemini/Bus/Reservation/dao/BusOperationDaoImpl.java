package com.capgemini.Bus.Reservation.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.Bus.Reservation.entity.Bus;
import com.capgemini.Bus.Reservation.entity.User;

@Repository
@Transactional
public class BusOperationDaoImpl implements BusOperationsDao{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	public BusOperationDaoImpl(EntityManager theEntityManager) {
		entityManager = theEntityManager;
	}

	public BusOperationDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void save (User theUser) 
	{
		Session currentSession = entityManager.unwrap(Session.class);
		theUser=new User();
		currentSession.saveOrUpdate(theUser);
	}

	@Override
	public List<User> showallUsers() 
	{
		Session currentSession = entityManager.unwrap(Session.class);
		Query<User> theQuery = currentSession.createQuery("select * from User",User.class);
		List<User> users = theQuery.getResultList();
		return users;
	}

	@Override
	public void deletebus(int busid) 
	{
		Session currentSession = entityManager.unwrap(Session.class);
		Query thequery = currentSession.createQuery(
				"delete from Bus where id =: busId");
		thequery.setParameter("busId", busid);
		thequery.executeUpdate();
	}

	@Override
	public Bus findById(int theId) 
	{
		Session currentSession = entityManager.unwrap(Session.class);
		Bus theBus = currentSession.get(Bus.class, theId);
		return theBus;
	}

}
