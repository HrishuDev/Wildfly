package com.capgemini.Bus.Reservation.dao;

import java.util.List;

import com.capgemini.Bus.Reservation.entity.Bus;
import com.capgemini.Bus.Reservation.entity.User;

public interface BusOperationsDao {

	public List<User> showallUsers();
	public void save(User theUser);
	public void deletebus(int busid);
	public Bus findById(int theId);

}
