package com.capgemini.Bus.Reservation.rest;

import java.util.List;

import javax.management.RuntimeErrorException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.Bus.Reservation.dao.BusOperationsDao;
import com.capgemini.Bus.Reservation.entity.Bus;
import com.capgemini.Bus.Reservation.entity.User;
import com.capgemini.Bus.Reservation.services.BusService;

@RestController
@RequestMapping("/api")
public class BusRestController {
	
	@Autowired
	private BusService busservice;

	@GetMapping("/users")
	public List<User> showallUsers(){
		return busservice.showallUsers();
	}
	
	@PostMapping("/Register")
	public User addUser(@RequestBody User theUser) {
		busservice.save(theUser);
		return theUser;	
	}
		
	@DeleteMapping("/buses/{busId}")
	public String deleteBus(@PathVariable int busId) {
		Bus tempBus = busservice.findById(busId);
		if(tempBus == null) {
			throw new RuntimeException("bus not found");
		}
		
		busservice.deletebus(busId);
		
		return "Delete bus "+busId;
	}

}
