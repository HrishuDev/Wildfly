package com.capgemini.Bus.Reservation.services;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.Bus.Reservation.dao.BusOperationDaoImpl;
import com.capgemini.Bus.Reservation.entity.Bus;
import com.capgemini.Bus.Reservation.entity.User;

@Transactional
@Service
public class BusServiceImpl implements BusService{

	@PersistenceContext
	EntityManager entitymanager;
	
	@Autowired
	BusOperationDaoImpl dao= new BusOperationDaoImpl();

	@Override
	public List<User> showallUsers() 
	{
		return dao.showallUsers();
	}

	@Override
	public void save(User theUser) 
	{
		dao.save(theUser);
	}

	@Override
	public void deletebus(int busid) 
	{
		dao.deletebus(busid);
	}

	@Override
	public Bus findById(int theId) 
	{
		return dao.findById(theId);
	}

}
