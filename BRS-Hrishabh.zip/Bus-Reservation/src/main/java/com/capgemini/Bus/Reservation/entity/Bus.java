package com.capgemini.Bus.Reservation.entity;

import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author rishabhwaykole
 * This is the bus entity
 */

@Entity
@Table(name="Bus")
public class Bus {

	//All the fields in bus entity
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "bus_Id")
	private int busId;
	
	@Column(name = "bus_Name")
	private String busName;
	
	@Column(name = "bus_Type")
	private String busType;
	
	@Column(name = "bus_Class")
	private String busClass;
	
	@Column(name = "no_of_Seats")
	private int noofSeats;
	
	@Column(name = "source")
	private String source;
	
	@Column(name = "destination")
	private String destination;
	
	@Column(name = "starttime")
	private Time startTime;
	
	@Column(name = "cost_per_Seat")
	private int costperSeat;

	//Constructors
	
	
	public Bus() {
		
	}

	public Bus(String busName, String busType, String busClass, int nofoSeats, String source,
			String destination, Time startTime, int costperSeat) {
		this.busName = busName;
		this.busType = busType;
		this.busClass = busClass;
		this.noofSeats = nofoSeats;
		this.source = source;
		this.destination = destination;
		this.startTime = startTime;
		this.costperSeat = costperSeat;
	}

	//Getters and Setters
	
	public int getBusId() {
		return busId;
	}

	public void setBusId(int busId) {
		this.busId = busId;
	}

	public String getBusName() {
		return busName;
	}

	public void setBusName(String busName) {
		this.busName = busName;
	}

	public String getBusType() {
		return busType;
	}

	public void setBusType(String busType) {
		this.busType = busType;
	}

	public String getBusClass() {
		return busClass;
	}

	public void setBusClass(String busClass) {
		this.busClass = busClass;
	}

	public int getNoofSeats() {
		return noofSeats;
	}

	public void setNoofSeats(int noofSeats) {
		this.noofSeats = noofSeats;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Time getStartTime() {
		return startTime;
	}

	public void setStartTime(Time startTime) {
		this.startTime = startTime;
	}

	public int getCostperSeat() {
		return costperSeat;
	}

	public void setCostperSeat(int costperSeat) {
		this.costperSeat = costperSeat;
	}

	//tostring method
	@Override
	public String toString() {
		return "Bus [busId=" + busId + ", busName=" + busName + ", busType=" + busType + ", busClass=" + busClass
				+ ", noofSeats=" + noofSeats + ", source=" + source + ", destination=" + destination + ", startTime="
				+ startTime + ", costperSeat=" + costperSeat + "]";
	}
	
	
	
	
	
	
}
