package com.capgemini.Bus.Reservation.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/*
This is for Passenger details

*/
@Entity
@Table(name="passengers")
public class Passenger {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "passenger_Id")
	private int passengerId;
	
	@Column(name = "user_Id")
	private int userId;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "gender")
	private String gender;
	
	@Column(name = "age")
	private int age;
	public int getPassengerId() {
		return passengerId;
	}
	public void setPassengerId(int passengerId) {
		this.passengerId = passengerId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Passenger(int userId, String name, String gender, int age) {
		super();
		this.userId = userId;
		this.name = name;
		this.gender = gender;
		this.age = age;
	}
	
	public Passenger() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Passenger [passengerId=" + passengerId + ", userId=" + userId + ", name=" + name + ", gender=" + gender
				+ ", age=" + age + "]";
	}
	
	
}
