package com.capgemini.Bus.Reservation;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import junit.framework.Assert;

import com.capgemini.Bus.Reservation.dao.BusOperationsDao;
import com.capgemini.Bus.Reservation.entity.Bus;



@SuppressWarnings("deprecation")
@RunWith(SpringRunner.class)
@SpringBootTest
class BusReservationApplicationTests {

	@Autowired
	BusOperationsDao busDao;
	
	@Test
	public void findBusById() {
		Bus bus = busDao.findById(1);
		
		Assert.assertEquals("Volvo", bus.getBusName());
        Assert.assertEquals("Sleeper", bus.getBusType());
        return;
		
	}

}
