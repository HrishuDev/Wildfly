package com.cg.SpringBatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBatchDBtoCsvApplicationTests {

	@Test
	void contextLoads() {
	}

}
