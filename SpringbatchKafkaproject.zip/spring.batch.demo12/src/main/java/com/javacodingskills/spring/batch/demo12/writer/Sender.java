package com.javacodingskills.spring.batch.demo12.writer;

import com.javacodingskills.spring.batch.demo12.model.Employee;
import com.javacodingskills.spring.batch.demo12.processor.EmployeeProcessor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class Sender {

	private static final Logger log = LoggerFactory.getLogger(Sender.class);
	
    @Autowired
    private KafkaTemplate<String, Employee> kafkaTemplate;

    public void send(Employee employee) {
    	log.info("[! CALLING SEND IN Sender !]");
        kafkaTemplate.send("EMPLOYEE", employee);
    }
}