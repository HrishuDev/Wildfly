package com.javacodingskills.spring.batch.demo12.model;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.javacodingskills.spring.batch.demo12.dto.EmployeeDTO;

@Data
@Entity
public class Employee {

	private static final Logger log = LoggerFactory.getLogger(Employee.class);
	
    @Id
    private String employeeId;
    private String firstName;
    private String lastName;
    private int age;
    private String email;
	public String getEmployeeId() {
		log.info("[! GETTING EMPLOYEE ID FROM EMPLOYEE !]");
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		log.info("[! SETTING EMPLOYEE ID FROM EMPLOYEE !]");
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		log.info("[! GETTING FIRSTNAME FROM EMPLOYEE !]");
		return firstName;
	}
	public void setFirstName(String firstName) {
		log.info("[! SETTING FIRSTNAME FROM EMPLOYEE !]");
		this.firstName = firstName;
	}
	public String getLastName() {
		log.info("[! GETTING LASTNAME FROM EMPLOYEE !]");
		return lastName;
	}
	public void setLastName(String lastName) {
		log.info("[! SETTING LASTNAME FROM EMPLOYEE !]");
		this.lastName = lastName;
	}
	public int getAge() {
		log.info("[! GETTING AGE FROM EMPLOYEE !]");
		return age;
	}
	public void setAge(int age) {
		log.info("[! SETTING AGE FROM EMPLOYEE !]");
		this.age = age;
	}
	public String getEmail() {
		log.info("[! GETTING EMAIL FROM EMPLOYEE !]");
		return email;
	}
	public void setEmail(String email) {
		log.info("[! SETTING EMAIL FROM EMPLOYEE !]");
		this.email = email;
	}

}