package com.javacodingskills.spring.batch.demo12.controller;

import com.javacodingskills.spring.batch.demo12.runner.JobRunner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/*
url: http://localhost:8080/run/job
 */

@RestController
@RequestMapping("/run")
public class JobController {

	private static final Logger log = LoggerFactory.getLogger(JobController.class);
	
    private JobRunner jobRunner;

    @Autowired
    public JobController(JobRunner jobRunner) {
    	log.info("[! CALLING jobController CONSTRUCTOR !]");
        this.jobRunner = jobRunner;
    }

    @RequestMapping(value = "/job")
    public String runJob() {
        jobRunner.runBatchJob();
        log.info("[! RUNNING THE JOB IN jobController !]");
        return String.format("Job Demo12 submitted successfully.");
    }
}
