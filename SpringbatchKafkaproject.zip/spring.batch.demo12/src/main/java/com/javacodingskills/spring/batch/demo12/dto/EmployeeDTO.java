package com.javacodingskills.spring.batch.demo12.dto;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import lombok.Data;

@Data
public class EmployeeDTO {

	private static final Logger log = LoggerFactory.getLogger(EmployeeDTO.class);
	
    private String employeeId;
    private String firstName;
    private String lastName;
    private String email;
    private int age;
	public String getEmployeeId() {
		log.info("[! GETTING EMPLOYEE ID FROM EmployeeDTO !]");
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		log.info("[! SETTING EMPLOYEE ID FROM EmployeeDTO !]");
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		log.info("[! GETTING FIRSTNAME FROM EmployeeDTO !]");
		return firstName;
	}
	public void setFirstName(String firstName) {
		log.info("[! SETTING FIRSTNAME FROM EmployeeDTO !]");
		this.firstName = firstName;
	}
	public String getLastName() {
		log.info("[! GETTING LASTNAME FROM EmployeeDTO !]");
		return lastName;
	}
	public void setLastName(String lastName) {
		log.info("[! SETTING LASTNAME FROM EmployeeDTO !]");
		this.lastName = lastName;
	}
	public String getEmail() {
		log.info("[! GETTING EMAIL FROM EmployeeDTO !]");
		return email;
	}
	public void setEmail(String email) {
		log.info("[! SETTING EMAIL FROM EmployeeDTO !]");
		this.email = email;
	}
	public int getAge() {
		log.info("[! GETTING AGE FROM EmployeeDTO !]");
		return age;
	}
	public void setAge(int age) {
		log.info("[! SETTING AGE FROM EmployeeDTO !]");
		this.age = age;
	}
    
}
