package com.javacodingskills.spring.batch.demo12.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;

@Configuration
@EnableAsync
public class BaseConfig {
	
	private static final Logger log = LoggerFactory.getLogger(BaseConfig.class);

    public JobRepository jobRepository;

    @Autowired
    public BaseConfig(JobRepository jobRepository) {
    	log.info("[! CREATING JOB REPOSITORY IN BaseConfig!]");
        this.jobRepository = jobRepository;
    }

    @Bean
    public JobLauncher simpleJobLauncher() {
    	log.info("[! LAUNCHING THE JOB IN BaseConfig!]");
        SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
        jobLauncher.setJobRepository(jobRepository);
        return jobLauncher;
    }

}
