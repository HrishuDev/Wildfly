package com.javacodingskills.spring.batch.demo12.utils;

public class Constants {

    public static final String FILE_NAME_CONTEXT_KEY = "fileName";
    public static final String FILE_PATH_EMPCSV = "/C:\\Users\\hrisverm\\Downloads\\SpringBatch-master\\18_SpringBatch_Demo12_Tasklet_Kafka\\spring.batch.demo12\\src\\main\\resources\\employees.csv";
}
