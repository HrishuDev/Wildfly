package com.javacodingskills.spring.batch.demo12;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.kafka.annotation.EnableKafka;

@SpringBootApplication
@EnableBatchProcessing
@EnableKafka
@ComponentScan(basePackages = {"com.javacodingskills.spring.batch.demo12"})
public class SpringBatchDemo12Application {

	private static final Logger log = LoggerFactory.getLogger(SpringBatchDemo12Application.class);
	public static void main(String[] args) {
		log.info("[! CALLING MAIN CLASS SpringBatchDemo12Application !]");
		SpringApplication.run(SpringBatchDemo12Application.class, args);
	}

}
