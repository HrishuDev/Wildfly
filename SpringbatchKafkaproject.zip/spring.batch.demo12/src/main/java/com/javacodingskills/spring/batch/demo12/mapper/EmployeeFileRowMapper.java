package com.javacodingskills.spring.batch.demo12.mapper;

import com.javacodingskills.spring.batch.demo12.dto.EmployeeDTO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;

public class EmployeeFileRowMapper implements FieldSetMapper<EmployeeDTO> {

	private static final Logger log = LoggerFactory.getLogger(EmployeeFileRowMapper.class);
	
    @Override
    public EmployeeDTO mapFieldSet(FieldSet fieldSet) {
    	log.info("[! CALLING MAP_FIELD_SET IN EmployeeFileRowMapper!]");
        EmployeeDTO employee = new EmployeeDTO();
        employee.setEmployeeId(fieldSet.readString("employeeId"));
        employee.setFirstName(fieldSet.readString("firstName"));
        employee.setLastName(fieldSet.readString("lastName"));
        employee.setEmail(fieldSet.readString("email"));
        employee.setAge(fieldSet.readInt("age"));

        return employee;
    }

}
