package com.cg.consumer.service;

import java.util.concurrent.CountDownLatch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.cg.consumer.model.Employee;

@Component
public class Reciever 
{
	private static final Logger log = LoggerFactory.getLogger(Reciever.class);
	
	private CountDownLatch latch= new CountDownLatch(1);
	
	@KafkaListener(topics="EMPLOYEE")
	public void recieve(Employee employee)
	{
		log.info("[! CALLING RECIEVE IN Reciever !]");
		System.out.println("Recieved Employee details='{}'"+employee.toString());
		latch.countDown();
	}
}
