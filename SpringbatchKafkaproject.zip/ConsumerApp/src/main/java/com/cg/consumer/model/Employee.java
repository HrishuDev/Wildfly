package com.cg.consumer.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class Employee 
{
	private static final Logger log = LoggerFactory.getLogger(Employee.class);
	
	private String employeeId;
	private String firstName;
	private String lastName;
	private int age;
	private String email;
	public String getEmployeeId() {
		log.info("GETTING EMPLOYEE ID IN Employee");
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		log.info("SETTING EMPLOYEE ID IN Employee");
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		log.info("GETTING FIRSTNAME IN Employee");
		return firstName;
	}
	public void setFirstName(String firstName) {
		log.info("SETTING FIRSTNAME IN Employee");
		this.firstName = firstName;
	}
	public String getLastName() {
		log.info("GETTING LASTNAME IN Employee");
		return lastName;
	}
	public void setLastName(String lastName) {
		log.info("SETTING LASTNAME IN Employee");
		this.lastName = lastName;
	}
	public int getAge() {
		log.info("GETTING AGE IN Employee");
		return age;
	}
	public void setAge(int age) {
		log.info("SETTING AGE IN Employee");
		this.age = age;
	}
	public String getEmail() {
		log.info("GETTING EMAIL IN Employee");
		return email;
	}
	public void setEmail(String email) {
		log.info("SETTING EMAIL IN Employee");
		this.email = email;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName + ", age="
				+ age + ", email=" + email + "]";
	}
	
}
