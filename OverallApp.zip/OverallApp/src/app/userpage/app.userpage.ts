import { Component } from '@angular/core';
import { BusService } from '../app.busservice';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
    selector: 'app-user',
    templateUrl: './app.userpage.html',
    styleUrls: ['./app.userpage.css'],
    providers:[BusService]

  })
  export class UserPageComponent{
      uId:number;
      
      constructor(private busService:BusService,private route:ActivatedRoute,private router:Router){
          
      }
      ngOnInit() {
        this.uId=this.route.snapshot.params['userId'];
        console.log("In booking "+this.uId);
       
      }

      
      getUserId(userId:number){
          userId=this.uId;
          this.router.navigate(['/createBookings',userId]);
      }

      getUserId1(userId:number){
        userId=this.uId;
        this.router.navigate(['/showBookingDetails',userId]);
    }

    getUserId2(userId:number){
      userId=this.uId;
      this.router.navigate(['/cancelBooking',userId]);
  }

  getUserId3(userId:number){
    userId=this.uId;
    this.router.navigate(['/showSeatsLeft',userId]);
}
  }