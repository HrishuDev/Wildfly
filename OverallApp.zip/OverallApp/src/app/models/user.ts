export class User {
    userId: number;
    fname: String;
    lname: String;
    username: String;
    password: String;
    email:String    
    phoneno:String;
    dob:Date;
    adharcardno:String;
}
