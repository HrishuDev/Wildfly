export class Booking{
    bookingId:number;
    userId:number;
    busId:number;
    date:Date;
    noofpassengers:number;
    modeofpay:String;
    totalcost:number;
    bookingstatus:string;
}