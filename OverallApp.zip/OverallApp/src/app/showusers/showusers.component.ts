import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { BusService } from '../app.busservice';


@Component({
  selector: 'app-showusers',
  templateUrl: './showusers.component.html',
  styleUrls: ['./showusers.component.css']
})
export class ShowusersComponent implements OnInit {

  flag: boolean = true;
  userList: User[]=[];
  userListCopy: User[]=[];

  constructor(private service: BusService) { }

//   ngOnInit(){
//     this.service.showUser().subscribe((data : any)=> this.userList= data);
// }
ngOnInit() {
  this.service.showUser().subscribe(res => 
    {
    // this.userList = res.slice()
    // this.userListCopy = res.slice()

        this.userList=res;
    })
  }
deleteUser(id: any):any{
    this.service.deleteUser(id).subscribe();
    alert("User deleted successfully")
    location.reload();
}

search(id) {
  this.userList = this.userListCopy
  this.userList = this.userList.filter(x => x.userId == id)
  if (this.userList.length == 0) {
    alert("No Data Found for Id : " + id)
    this.userList = this.userListCopy
  }
}

clear() {
  this.userList = this.userListCopy
}
}

