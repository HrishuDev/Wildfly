import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Booking } from './models/booking';
import { Passenger } from './models/passenger';
import { Bus } from './models/bus';
import { User } from './models/user';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
  })
export class BusService{
    constructor(private http:HttpClient){}

    addUser(user:User){
        //debugger
        return this.http.post('http://localhost:9099/api/adduser',user);
    }

    getBookings(bookingId:number){
        return this.http.get<Booking>('http://localhost:9099/api/users/bookings/'+bookingId);
    }

    cancelBooking(bookingId:number){
        return this.http.delete('http://localhost:9099/api/users/bookingdel/'+bookingId)
    }

    getAllBuses():Observable<Bus[]>{
        return this.http.get<Bus[]>('http://localhost:9099/api/buses');
    }

    getPassenger(passengerId:number){
        return this.http.get('http://localhost:9099/api/users/booking/'+passengerId);
    }

    getPassengerBooking(passengerId:number){
        return this.http.get('http://localhost:9099/api/users/bookings/'+passengerId);
    }

    addPassenger(passenger:Passenger){
        return this.http.post('http://localhost:9099/api/users/add',passenger);
    }

    addBooking(booking:Booking){
        return this.http.post('http://localhost:9099/api/booking/users',booking);
    }

    // updateBus(bus:Bus){
    //     return this.http.put('http://localhost:9099/api/buses/update',bus);
    // }

    getSingleBus(busId:number){
        return this.http.get<Bus>('http://localhost:9099/api/getbus/'+busId);
    }

    loginUser(username:string,password:string){
        //debugger
        let user=new User();
        user.username=username;
        user.password=password;
        return this.http.post('http://localhost:9099/api/login',user);
    }


    getseatLeftByBusId(busId:number){
        return this.http.get('http://localhost:9099/api/getseatleftbybusid/'+busId);
    }


    getBookingByUserId(userId:number):Observable<Booking[]>{
        return this.http.get<Booking[]>('http://localhost:9099/api/getbookingbyuserid/'+userId);
    }








    // Admin


    addBus(data:any){
        debugger
        let form=new FormData();
        form.append("busName", data.busName);
        form.append("busType", data.busType);
        form.append("busClass", data.busClass);
        form.append("source", data.source);
        form.append("destination", data.destination);
        form.append("startTime", data.startTime);
        form.append("endTime", data.endTime);
        form.append("costperSeat", data.costPerSeat);
        form.append("noofSeats", data.noOfSeats);

        console.log(data);
        return this.http.post('http://localhost:9099/api/buses', data);

    }

    showUser():Observable<User[]>{
        return this.http.get<User[]>('http://localhost:9099/api/users');
    }

    deleteUser(id:number){ 
        return this.http.delete('http://localhost:9099/api/deleteUsers/'+id);
    }

    deleteBus(id:number){ 
        return this.http.delete('http://localhost:9099/api/delbuses/'+id);
    }
}