package com.capgemini.Bus.Reservation.dao;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.transaction.Transaction;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.Bus.Reservation.entity.Booking;
import com.capgemini.Bus.Reservation.entity.Bus;
import com.capgemini.Bus.Reservation.entity.Passenger;
import com.capgemini.Bus.Reservation.entity.User;

@Repository
public class BusOperationDaoImpl implements BusOperationsDao{
	
	private EntityManager entityManager;
	
	@Autowired
	public BusOperationDaoImpl(EntityManager theEntityManager) {
		entityManager = theEntityManager;
	}
	

	//Adding User(Registration)-Customer Module	
	@Override
	@Transactional
	public void addUser(User user) {
		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.save(user);		
	}

	//Displaying all buses-Admin module	
	@Override
	@Transactional
	public List<Bus> findallBuses() {
		// TODO Auto-generated method stub
		Session currentSession = entityManager.unwrap(Session.class);
		Query<Bus> theQuery = currentSession.createQuery("from Bus",Bus.class);
		List<Bus> buses = theQuery.getResultList();
		return buses;
	}
	
	//Find all Users-Admin module	
	@Override
	@Transactional
	public List<User> findallUsers() {
		// TODO Auto-generated method stub
		Session currentSession = entityManager.unwrap(Session.class);
		Query<User> theQuery = currentSession.createQuery("from User",User.class);
		List<User> users = theQuery.getResultList();
		return users;
	}

	//Find bus by Id	
	@Override
	@Transactional
	public Bus findById(int theId) {
		// TODO Auto-generated method stub
		Session currentSession = entityManager.unwrap(Session.class);
		Bus theBus = currentSession.get(Bus.class, theId);
		return theBus;
	}
	
	//add bus details
	@Override
	@Transactional
	public void save(Bus theBus) {
		// TODO Auto-generated method stub
		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.saveOrUpdate(theBus);
		
	}

	//delete of bus by bus Id
	@Override
	@Transactional
	public void deletebyId(int theId) {
		// TODO Auto-generated method stub
		Session currentSession = entityManager.unwrap(Session.class);
		Query thequery = currentSession.createQuery(
				"delete from Bus where id =: busId");
		thequery.setParameter("busId", theId);
		thequery.executeUpdate();		
	}

	//find passenger by Id
	@Override
	@Transactional
	public Passenger passengerfindById(int theId) {
		Session currentSession = entityManager.unwrap(Session.class);
		Passenger thePassenger = currentSession.get(Passenger.class, theId);
		return thePassenger;
	}

	//Add passenger to passenger table	
	@Override
	@Transactional
	public void savePassenger(Passenger thePassenger) {
		// TODO Auto-generated method stub
		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.saveOrUpdate(thePassenger);
	}

	//add booking details to booking table
	@Override
	@Transactional
	public void saveBookings(Booking theBooking) {
		// TODO Auto-generated method stub
		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.saveOrUpdate(theBooking);
	}
	
	//find booking details by Id
	@Override
	@Transactional
	public Booking bookingfindById(int theId) {
		Session currentSession = entityManager.unwrap(Session.class);
		Booking theBooking = currentSession.get(Booking.class, theId);
		return theBooking;
	}

	//delete booking details By Id
	@Override
	@Transactional
	public void deletebookingbyId(int theId) {
		// TODO Auto-generated method stub
		Session currentSession = entityManager.unwrap(Session.class);
		Query thequery = currentSession.createQuery(
				"delete from Booking where id =: bookingId");
		thequery.setParameter("bookingId", theId);
		thequery.executeUpdate();
	}
	
	// Login validation
	@Override
	public int loginUser(String username, String password) {
		User user=new User();
		Session currentSession = entityManager.unwrap(Session.class);
		Query<User> tq=currentSession.createQuery("from User user "
				+ "where user.username=:username and user.password=:password",User.class);
		tq.setParameter("username", username);
		tq.setParameter("password", password);
		try {
			user=tq.uniqueResult();
			//System.out.println(user);
			//System.out.println(user.getUsername()+" "+user.getPassword());
			if(user.getUsername()==null && user.getPassword()==null) {
				throw new NullPointerException();
			}
			else if(user.getUsername()!=username && user.getPassword()!=password) {
				throw new NoResultException();
			}			
		}
		catch (NullPointerException | NoResultException e) {
			System.out.println("Record not found");
		}		
		return user.getUserId();
	}
	
	//number of seats left 
	@Override
	public int getSeatsLeftByBusId(int busId) {
		int nos=0;//number of seats
		Integer noofPass=null;//Number of passengers
		int count=0;// for storing results of number of seats left
		Session currentSession = entityManager.unwrap(Session.class);
		Query<Booking> q=currentSession.createQuery("from Booking booking where booking.busId=:busId",Booking.class);
		q.setParameter("busId", busId);
		List<Booking> book=q.getResultList();
		List<Integer> listnop = book.stream().map(Booking::getNoofpassengers).collect(Collectors.toList());
		for(int i=0;i<listnop.size();i++) {
			noofPass=listnop.get(i);
				count+=noofPass;			
		}
		Query<Bus> theQuery = currentSession.createQuery("from Bus bus where bus.busId=:busId",Bus.class);
		theQuery.setParameter("busId", busId);
		Bus bus=theQuery.getSingleResult();
		nos=bus.getNoofSeats();		
		int result=nos-count;		
		return result;
	}
	
	//for show booking details based on user id
	@Override
	public List<Booking> getBookingByUserId(int userId) {
		Session currentSession = entityManager.unwrap(Session.class);
		Query<Booking> theQuery = currentSession.createQuery("from Booking booking where booking.userId=:userId",Booking.class);
		theQuery.setParameter("userId", userId);
		List<Booking> booking=theQuery.getResultList();
		return booking;
	}


	@Override
	public User findByUserid(int theId) {
		// TODO Auto-generated method stub
		Session currentSession = entityManager.unwrap(Session.class);
		User user = currentSession.get(User.class, theId);
		return user;
	}


	@Override
	public Bus DeleteBus(int theId) {
		// TODO Auto-generated method stub
		Bus tempBus=entityManager.find(Bus.class, theId);
		System.out.println(tempBus);
		if(tempBus==null)
			System.out.println("Not found");
		else
			entityManager.remove(tempBus);
		
		return tempBus;
	}


	@Override
	public User DeleteUser(int theId) {
		// TODO Auto-generated method stub
		User tempUser=entityManager.find(User.class, theId);
		System.out.println(tempUser);
		if(tempUser==null)
			System.out.println("Not found");
		else
//		entityManager.remove(tempBus);
			entityManager.remove(tempUser);
		return tempUser;
	}


	@Override
	public Transaction getTransaction(int bookingId) {
		Transaction transaction=(Transaction) entityManager.find(Booking.class, bookingId);
		if(transaction==null)
			System.out.println("Not Found");
		else
		{
			Session currentSession = entityManager.unwrap(Session.class);
			currentSession.save(transaction);
		    transaction = currentSession.get(Transaction.class, bookingId);
		}
		return transaction;			
	}		
}
