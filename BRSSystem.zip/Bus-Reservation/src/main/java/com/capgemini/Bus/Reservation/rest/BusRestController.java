package com.capgemini.Bus.Reservation.rest;

import java.util.List;

import javax.persistence.NoResultException;
import javax.transaction.Transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.Bus.Reservation.dao.BusOperationsDao;
import com.capgemini.Bus.Reservation.entity.Booking;
import com.capgemini.Bus.Reservation.entity.Bus;
import com.capgemini.Bus.Reservation.entity.Passenger;
import com.capgemini.Bus.Reservation.entity.User;
import com.capgemini.Bus.Reservation.service.BusReservationService;
import com.capgemini.Bus.Reservation.service.BusReservationServiceImpl;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api")
public class BusRestController {
	
	private BusReservationService service;
	
	@Autowired
	public BusRestController(BusReservationService theBusReservationService) {
		service=theBusReservationService;
	}
	
	//inserting User details for Registration
	@PostMapping("/adduser")
	public void addUser(@RequestBody User user) {
		service.addUser(user);
	}
	
	//displaying all bus details
	@GetMapping("/buses")
	public List<Bus> findAllBuses(){
		return service.findallBuses();
		
	}
	
	//displaying all Users
	@GetMapping("/users")
	public List<User> findAllUsers(){
		return service.findallUsers();
	}
	
	//get bus details based on bus Id
	@GetMapping("/getbus/{busId}")
	public Bus getBus(@PathVariable int busId) {	
		Bus theBus = null;
		try {
			theBus = service.findById(busId);
			if(busId!=theBus.getBusId()) {
				throw new NoResultException();
			}			
		}
		catch(NullPointerException | NoResultException e) {
			System.out.println("Bus Id not found");
		}		
		return theBus;		
	}
	
	//get passenger details by passenger ID
	@GetMapping("/users/booking/{passengerId}")
	public Passenger getPassenger(@PathVariable int passengerId) {
		
		Passenger thePassenger = service.passengerfindById(passengerId);		
		if(thePassenger == null) {
			throw new RuntimeException("user id not found"+ thePassenger);
		}
		return thePassenger;		
	}
	
	//get Passenger Booking details
	@GetMapping("/users/bookings/{bookingId}")
	public Booking getPassengerBookings(@PathVariable int bookingId) {	
		Booking theBooking = service.bookingfindById(bookingId);		
		if(theBooking == null) {
			throw new RuntimeException("user id not found"+ theBooking);
		}
		return theBooking;		
	}
	// Inserting buses
	@PostMapping("/buses")
	public Bus addBus(@RequestBody Bus theBus) {
		try {
		theBus.setBusId(0);
		service.save(theBus);
		}catch ( Exception e) {
			// TODO: handle exception
			System.out.println("Exception"+e);
		}
		return theBus;	
	}
	//Inserting passenger details
	@PostMapping("/users/add")
	public Passenger addPassenger(@RequestBody Passenger thePassenger) {
		
		service.savePassenger(thePassenger);
		return thePassenger;	
	}
	//inserting booking details
	@PostMapping("/booking/users")
	public Booking addBooking(@RequestBody Booking theBooking) {
		
		service.saveBookings(theBooking);
		return theBooking;	
	}
	
	//update bus details
	@PutMapping("/buses/update")
	public Bus updateBus(@RequestBody Bus theBus)
	{
		service.save(theBus);
		
		return theBus;
	}
	
	//deleting of bus
	@DeleteMapping("/delbuses/{busId}")
	public String deleteBus(@PathVariable int busId) {
		Bus tempBus = service.findById(busId);
		System.out.println(tempBus);
		if(tempBus == null) {
			throw new RuntimeException("bus not found");
		}
		
		service.deletebyId(busId);
		
		return "Delete bus "+busId;
	}
	
	//deleting of booking details for cancellation
	@DeleteMapping("/users/bookingdel/{bookingId}")
	public int deleteBooking(@PathVariable int bookingId) {
		System.out.println(bookingId);
		Booking tempBooking=null;
		try {
			tempBooking = service.bookingfindById(bookingId);
			if(tempBooking.getBookingId() != bookingId) {
				throw new NullPointerException();
			}
			service.deletebookingbyId(bookingId);
		}
		catch(NullPointerException e) {
			System.out.println("booking Id not found");
		}
		
		return tempBooking.getBookingId();
	}
	
	//Login Page
	@PostMapping(value="/login")
	public int loginUser(@RequestBody User user) {
		return service.loginUser(user.getUsername(),user.getPassword());
	} 
 
	// for displaying number of seats left
	@GetMapping("/getseatleftbybusid/{busId}")
	public int getSeatsLeftByBusId(@PathVariable int busId) {
		return service.getSeatsLeftByBusId(busId);
	}
	
	//for displaying booking details 
	@GetMapping("/getbookingbyuserid/{userId}")
	public List<Booking> getBookingByUserId(@PathVariable int userId) {
		return service.getBookingByUserId(userId);
	}
	
	@DeleteMapping("/deleteUsers/{userId}")
	public String deleteUser(@PathVariable int userId) 
	{
		User tempUser = null;
		try {
			tempUser=service.DeleteUser(userId);
			if(tempUser == null) {
				throw new RuntimeException("bus not found");
			}
		}
		catch (Exception e) {
			System.out.println(e.getMessage()+"Exception in deleteUser method in Controller");
		}

		return "Delete user "+userId;
	}
	
	@GetMapping("/transaction/{bookingId}")
	public Transaction getTransaction(@PathVariable int bookingId)
	{
		return service.getTransaction(bookingId);
		
	}
}
