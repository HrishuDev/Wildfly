package com.capgemini.Bus.Reservation.service;

import java.util.List;

import javax.transaction.Transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.Bus.Reservation.dao.BusOperationsDao;
import com.capgemini.Bus.Reservation.entity.Booking;
import com.capgemini.Bus.Reservation.entity.Bus;
import com.capgemini.Bus.Reservation.entity.Passenger;
import com.capgemini.Bus.Reservation.entity.User;

@Service
@Transactional
public class BusReservationServiceImpl implements BusReservationService{

//@Autowired
//BusOperationsDao busdao;


		private BusOperationsDao busDao;

	@Autowired
	public BusReservationServiceImpl(BusOperationsDao theBusOperationsDao) {
		busDao = theBusOperationsDao;
	}
	
	
	@Override
	public void addUser(User user) {
		busDao.addUser(user);
		
	}

	@Override
	public List<Bus> findallBuses() {
		// TODO Auto-generated method stub
		return busDao.findallBuses();
	}

	@Override
	public List<User> findallUsers() {
		// TODO Auto-generated method stub
		return busDao.findallUsers();
	}

	@Override
	public Bus findById(int theId) {
		// TODO Auto-generated method stub
		return busDao.findById(theId);
	}

	@Override
	public void save(Bus theBus) {
		// TODO Auto-generated method stub
		busDao.save(theBus);
	}

	@Override
	public void deletebyId(int theId) {
		// TODO Auto-generated method stub
		busDao.deletebyId(theId);
	}

	@Override
	public void deletebookingbyId(int theId) {
		// TODO Auto-generated method stub
		busDao.deletebookingbyId(theId);
	}

	@Override
	public Passenger passengerfindById(int theId) {
		// TODO Auto-generated method stub
		return busDao.passengerfindById(theId);
	}

	@Override
	public void savePassenger(Passenger thePassenger) {
		// TODO Auto-generated method stub
		busDao.savePassenger(thePassenger);
	}

	@Override
	public void saveBookings(Booking theBooking) {
		// TODO Auto-generated method stub
		busDao.saveBookings(theBooking);
	}

	@Override
	public Booking bookingfindById(int theId) {
		// TODO Auto-generated method stub
		return busDao.bookingfindById(theId);
	}

	@Override
	public int loginUser(String username, String password) {
		// TODO Auto-generated method stub
		return busDao.loginUser(username, password);
	}

	@Override
	public int getSeatsLeftByBusId(int busId) {
		// TODO Auto-generated method stub
		return busDao.getSeatsLeftByBusId(busId);
	}

	@Override
	public List<Booking> getBookingByUserId(int userId) {
		// TODO Auto-generated method stub
		return busDao.getBookingByUserId(userId);
	}


	@Override
	public User findByUserid(int theId) {
		// TODO Auto-generated method stub
		return busDao.findByUserid(theId);
	}


	@Override
	public Bus DeleteBus(int theId) {
		// TODO Auto-generated method stub
		return busDao.DeleteBus(theId);
	}


	@Override
	public User DeleteUser(int theId) {
		// TODO Auto-generated method stub
		return busDao.DeleteUser(theId);
	}


	@Override
	public Transaction getTransaction(int bookingId) {
		// TODO Auto-generated method stub
		return busDao.getTransaction(bookingId);
	}
	
	}
