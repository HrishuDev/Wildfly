package com.capgemini.Bus.Reservation.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/*
	This is for ticket booking by User

*/
@Entity
@Table(name="bookings")
public class Booking {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "booking_Id")
	private int bookingId;
	
	@Column(name = "user_Id")
	private int userId;
	
	@Column(name = "bus_Id")
	private int busId;
	
	@Column(name = "date")
	private Date date;
	
	@Column(name = "no_of_passengers")
	private int noofpassengers;
	
	@Column(name = "mode_of_pay")	
	private String modeofpay;
	
	@Column(name = "total_cost")
	private int totalcost;
	
	@Column(name = "booking_status")
	private String bookingstatus;
public Booking(int userId, int busId, Date date, int noofpassengers, String modeofpay, int totalcost,
		String bookingstatus) {
	super();
	this.userId = userId;
	this.busId = busId;
	this.date = date;
	this.noofpassengers = noofpassengers;
	this.modeofpay = modeofpay;
	this.totalcost = totalcost;
	this.bookingstatus = bookingstatus;
}
@Override
public String toString() {
	return "Booking [bookingId=" + bookingId + ", userId=" + userId + ", busId=" + busId + ", date=" + date
			+ ", noofpassengers=" + noofpassengers + ", modeofpay=" + modeofpay + ", totalcost=" + totalcost
			+ ", bookingstatus=" + bookingstatus + "]";
}
public int getBookingId() {
	return bookingId;
}
public void setBookingId(int bookingId) {
	this.bookingId = bookingId;
}
public int getUserId() {
	return userId;
}
public void setUserId(int userId) {
	this.userId = userId;
}
public int getBusId() {
	return busId;
}
public void setBusId(int busId) {
	this.busId = busId;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}
public int getNoofpassengers() {
	return noofpassengers;
}
public void setNoofpassengers(int noofpassengers) {
	this.noofpassengers = noofpassengers;
}
public String getModeofpay() {
	return modeofpay;
}
public void setModeofpay(String modeofpay) {
	this.modeofpay = modeofpay;
}
public int getTotalcost() {
	return totalcost;
}
public void setTotalcost(int totalcost) {
	this.totalcost = totalcost;
}
public String getBookingstatus() {
	return bookingstatus;
}
public void setBookingstatus(String bookingstatus) {
	this.bookingstatus = bookingstatus;
}
public Booking() {
	// TODO Auto-generated constructor stub
}


}
