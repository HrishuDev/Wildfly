package com.capgemini.Bus.Reservation.entity;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "transaction")
public class Transactions {

	@Id
	@Column(name = "transactionId")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int transactionId;
	
	@Column(name = "totalAmount")
	private double totalAmount;
	
	@Column(name = "dot")
	private LocalDate dot;
	
	@OneToOne(cascade = CascadeType.ALL)
//	@JoinColumn(name = "transactionId", referencedColumnName = "user_Id")
	private User user;
	
	@OneToOne(cascade = CascadeType.ALL)
//	@JoinColumn(name = "transactionId", referencedColumnName = "booking_Id")
	private Booking booking;
	
	@OneToOne(cascade = CascadeType.ALL)
//	@JoinColumn(name = "transactionId", referencedColumnName = "bus_Id")
	private Bus bus;
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public LocalDate getDot() {
		return dot;
	}
	public void setDot(LocalDate dot) {
		this.dot = dot;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Booking getBooking() {
		return booking;
	}
	public void setBooking(Booking booking) {
		this.booking = booking;
	}
	public Bus getBus() {
		return bus;
	}
	public void setBus(Bus bus) {
		this.bus = bus;
	}
	public Transactions() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
