package com.capgemini.Bus.Reservation.service;

import java.util.List;

import javax.transaction.Transaction;

import com.capgemini.Bus.Reservation.entity.Booking;
import com.capgemini.Bus.Reservation.entity.Bus;
import com.capgemini.Bus.Reservation.entity.Passenger;
import com.capgemini.Bus.Reservation.entity.User;

public interface BusReservationService {
	
	public void addUser(User user);
		
	public List<Bus> findallBuses();
	
	public List<User> findallUsers();

	public Bus findById(int theId);
	
	public void save(Bus theBus);
	
	public void deletebyId(int theId);
	
	public User findByUserid(int theId);
	
	public Bus DeleteBus(int theId);
	
	public User DeleteUser(int theId);
	
	public void deletebookingbyId(int theId);

	public Passenger passengerfindById(int theId);
	
	public void savePassenger(Passenger thePassenger);
	
	public void saveBookings(Booking theBooking);

	public Booking bookingfindById(int theId);
	
	public int loginUser(String username,String password);
	
	public int getSeatsLeftByBusId(int busId);
	
	public List<Booking> getBookingByUserId(int userId);
	
	public Transaction getTransaction(int bookingId);

}
