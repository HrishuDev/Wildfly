package com.capgemini.Bus.Reservation.test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.Assert;

import com.capgemini.Bus.Reservation.dao.BusOperationDaoImpl;
import com.capgemini.Bus.Reservation.entity.Bus;
import com.capgemini.Bus.Reservation.exception.BusException;
import com.capgemini.Bus.Reservation.service.BusReservationServiceImpl;


@RunWith(SpringRunner.class)
@SpringBootTest
class FirstTest {

	@Test
	public void registerUser() {
		Bus bus = new Bus();
	
		BusReservationServiceImpl service= new BusReservationServiceImpl(); 
		BusOperationDaoImpl dao=new BusOperationDaoImpl();
		
		try {
			//Assert.notNull(service.AddBus(bus));
			Bus busTest= dao.AddBus(bus);
			Assert.notNull(busTest);
			
		} catch (BusException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
