package com.capgemini.Bus.Reservation.rest;

import java.util.List;

import javax.management.RuntimeErrorException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.Bus.Reservation.dao.BusOperationsDao;
import com.capgemini.Bus.Reservation.entity.Bus;
import com.capgemini.Bus.Reservation.entity.User;
import com.capgemini.Bus.Reservation.exception.BusException;
import com.capgemini.Bus.Reservation.service.IBusReservationService;

@CrossOrigin(origins = "*", value = "*")
@RestController
@RequestMapping("/api")
public class BusRestController {

	@Autowired
	IBusReservationService service;

	@GetMapping("/login")
	public ResponseEntity<?> login(@RequestParam("username") String username,
			@RequestParam("password") String password) {
		System.out.println(username + " " + password);
		if (username.equalsIgnoreCase("Admin") && password.equalsIgnoreCase("Admin@123")) {
			System.out.println("s");
			return new ResponseEntity<String>("Login Successful", HttpStatus.OK);
		} else {
			return new ResponseEntity<String>("Invalid Credentials", HttpStatus.BAD_REQUEST);
		}

	}

	@GetMapping("/buses")
	public List<Bus> ShowBuses() {

		return service.ShowBuses();
		// return busdao.ShowBuses();

	}

	@GetMapping("/users")
	public List<User> ShowUsers() {

		return service.ShowUsers();
	}

	@GetMapping("/buses/{busId}")
	public Bus findById(@PathVariable int busId) throws BusException {

		Bus theBus = null;
		try {
			theBus = service.findById(busId);

			if (theBus == null) {
				throw new RuntimeException("Bus id not found" + theBus);
			}
		} catch (BusException e) {
			System.out.println(e.getMessage() + "Exception in addBus method in Controller");
		}
		return theBus;

	}

	@PostMapping("/addBus")

	public Bus addBus(@RequestBody Bus theBus) throws BusException {
		System.out.println("s");
		Bus addbus = null;
		try {
			addbus = service.AddBus(theBus);
		} catch (BusException e) {
			System.out.println(e.getMessage() + "Exception in addBus method in Controller");
		}
		return addbus;
	}

	@DeleteMapping("/buses/{busId}")

	public String deleteBus(@PathVariable int busId) throws BusException {
		Bus tempBus = null;
		try {
			tempBus = service.DeleteBus(busId);
			if (tempBus == null) {
				throw new RuntimeException("bus not found");
			}
		} catch (BusException e) {
			System.out.println(e.getMessage() + "Exception in deleteBus method in Controller");
		}
		return "Delete bus " + busId;
	}

	@DeleteMapping("/users/{userId}")

	public String deleteUser(@PathVariable int userId) throws BusException {
		User tempUser = null;
		try {
			tempUser = service.DeleteUser(userId);
			if (tempUser == null) {
				throw new RuntimeException("bus not found");
			}
		} catch (BusException e) {
			System.out.println(e.getMessage() + "Exception in deleteUser method in Controller");
		}

		return "Delete user " + userId;
	}

}
