package com.capgemini.Bus.Reservation.service;

import java.util.List;

import com.capgemini.Bus.Reservation.entity.Bus;
import com.capgemini.Bus.Reservation.entity.User;
import com.capgemini.Bus.Reservation.exception.BusException;

public interface IBusReservationService {
	
	public List<Bus> ShowBuses();
	
	public List<User> ShowUsers();

	public Bus findById(int theId) throws BusException;
	
	public Bus AddBus(Bus theBus) throws BusException;
	
	public Bus DeleteBus(int theId) throws BusException;

	public User DeleteUser(int theId) throws BusException;
}
