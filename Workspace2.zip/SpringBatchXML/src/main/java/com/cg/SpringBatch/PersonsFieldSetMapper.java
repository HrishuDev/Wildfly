package com.cg.SpringBatch;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

public class PersonsFieldSetMapper implements FieldSetMapper<Persons>
{
	static Persons persons;
	public Persons mapFieldSet(FieldSet fieldSet) throws BindException 
	{
		persons=new Persons();
		persons.setFirstName(fieldSet.readString(0));
		persons.setLastName(fieldSet.readString(1));
		persons.setEmail(fieldSet.readString(2));
		persons.setAge(fieldSet.readInt(3));
		return persons;
	}
	
}
