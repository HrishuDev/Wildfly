package com.cg.SpringBatch;

import org.springframework.batch.item.ItemProcessor;

public class PersonsItemProcessor implements ItemProcessor<Persons, Persons> 
{
    public Persons process(final Persons persons) throws Exception 
    {
        final String firstName = persons.getFirstName().toUpperCase();
        final String lastName = persons.getLastName().toUpperCase();

        final Persons transformedPerson = new Persons(firstName, lastName,persons.getEmail(),persons.getAge());

        System.out.println("Processing...");
        return transformedPerson;
    }

}